package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.AuthenticationPage;
import BASE_CLASSES.Homepage;

public class NewTest {
	
	WebDriver dr;
	Homepage hp ;
	SoftAssert sa;
	AuthenticationPage ap;
	Logger log;

	
  @Test(priority=1)
  public void homePageTest() {
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
	  dr = new ChromeDriver();
	  hp = new Homepage(dr);
	  hp.homepage();
	  String str = hp.get_Title();
	  sa = new SoftAssert();
	  sa.assertEquals(str, "My Store");
	  log=Logger.getLogger("devpinoyLogger");
	  	  log.info("\n==========================================================================\n"
	  	+ "-------------------------------HomePage Test--------------------------------\n"
	  	+ "============================================================================\n");
	  		log.info("Expected Value : My Store");
	  		log.info(" Actual Value : "+str);
	  		log.info(" Test Result: Passed");
	  

	 
  }
  
  @Test(priority=2)
  public void verifySigninTest()
  {
	 String str = hp.get_Text();
	  sa.assertEquals(str, "Sign in");
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("\n====================================================================================\n"
		  		+ "-------------------------------Verify Signin Test--------------------------------\n"
		  		+ "=================================================================================\n");
	  log.info("Expected Value : Sign in");
		log.info(" Actual Value : "+str);
		log.info(" Test Result: Passed");
		
  }
  
}
