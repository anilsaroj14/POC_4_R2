package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import BASE_CLASSES.AuthenticationPage;
import BASE_CLASSES.MyAccount;
import UTILITIES.ReadExcel;

public class NewTest1 extends NewTest{

	MyAccount ac;
	SoftAssert sa;
	AuthenticationPage ap;
	ReadExcel re;
	String [][] logintestdata;
	int flag = 0;

	@BeforeClass
	public void bc()
	{
		re = new ReadExcel();
		logintestdata = re.readExcel();
	}
	
	
	 
	 @Test(dataProvider = "logindataprovider", priority=3)
	  public void logInTest(String emailId, String pwd, String er)
	  {
		  ap = new AuthenticationPage(dr);
		  String str1 = ap.login(emailId, pwd);
		  sa = new SoftAssert();
		  sa.assertEquals(str1, "Login - My Store");
		  log=Logger.getLogger("devpinoyLogger");
		  log.info("\n==========================================================================\n"
			  		+ "-------------------------------Login Page Title Test--------------------------------\n"
			  		+ "============================================================================\n");
		    log.info("Expected Value : Login - My Store");
	  		log.info(" Actual Value : "+str1);
	  		log.info(" Test Result: Passed");
		  ac = new MyAccount(dr);
		  accountTest(flag);
		  verifyName(er);
		  ap.logout();
		  flag++;
		  

	  }
	  

	  
	  @DataProvider(name="logindataprovider")
	  public String[][] testData(){
		 
		  return logintestdata;
		  
	  }
	  
	  public void accountTest(int f)
	  {
		  String str2 = ac.get_Title();
		  sa = new SoftAssert();
		  String text = null;
		  if(f==0)
			  text = "My account - My Store";
		  else 
			  text = "Login - My Store";
		  sa.assertEquals(str2,text);
		  log=Logger.getLogger("devpinoyLogger");
		  log.info("\n===================================================================================\n"
			  		+ "-----------------------------------Account Test----------------------------------\n"
			  		+ "==================================================================================\n");
		  log.info("Expected Value : "+text);
	  		log.info(" Actual Value : "+str2);
	  		log.info(" Test Result: Passed");
			  
	  }

	  public void verifyName(String er)
	  {
		  String str2 = ac.get_Text();
		  sa = new SoftAssert();
		  sa.assertEquals(str2,er);
		  log=Logger.getLogger("devpinoyLogger");
		  log.info("\n===============================================================================\n"
			  		+ "-------------------------------Profile Name Test--------------------------------\n"
			  		+ "==============================================================================\n");
		  log.info("Expected Value : "+er);
	  		log.info(" Actual Value : "+str2);
	  		log.info(" Test Result: Passed");
		  
	  }
	  
}
