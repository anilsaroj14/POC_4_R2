package BASE_CLASSES;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AuthenticationPage {
	
	WebDriver dr;

	public AuthenticationPage(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);

	}

	@FindBy(xpath = "//*[@class = 'login']")
	WebElement signin;
	@FindBy(xpath = "//*[@id = 'email']")
	WebElement email;
	@FindBy(xpath = "//*[@id = 'passwd']")
	WebElement pass;
	@FindBy(xpath = "//*[@id = 'SubmitLogin']")
	WebElement clk;
	public String login(String emailId, String pwd)
	{
		signin.click();
		
		WebDriverWait wait = new WebDriverWait(dr,10);
		wait.until(ExpectedConditions.titleIs("Login - My Store"));
		
		String str = dr.getTitle();
		email.sendKeys(emailId);
		pass.sendKeys(pwd);
		clk.click();
		return str;
		
	}
	
	@FindBy(xpath = "//*[@class = 'logout']")
	 WebElement logout;
	public void logout()
	{
		try
		{
			if(logout.isDisplayed())
				logout.click();
		}
		catch(NoSuchElementException e)
		{
			
		}
	}
	
}
