package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Homepage {
	
	WebDriver dr;
	
	

	public Homepage(WebDriver dr) {
		
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}

	public void homepage()
	{
		
		dr.get("http://automationpractice.com/index.php");
	}

	public String get_Title()
	{
		WebDriverWait wait = new WebDriverWait(dr,10);
		wait.until(ExpectedConditions.titleIs("My Store"));
		
		return dr.getTitle();
	}
	
	@FindBy(xpath = "//*[@class = 'login']")
	WebElement signin;
	public String get_Text()
	{
		WebDriverWait wait = new WebDriverWait(dr,10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class = 'login']")));
		
		return signin.getText();
	}
	
	
	
	
}

